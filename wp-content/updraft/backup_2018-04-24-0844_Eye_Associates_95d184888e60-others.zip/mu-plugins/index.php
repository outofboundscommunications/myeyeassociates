<?php
// require WPMU_PLUGIN_DIR . '/gpr/index.php';
require WPMU_PLUGIN_DIR . '/mobile-detect/index.php';
// require WPMU_PLUGIN_DIR . '/device-detect/index.php';
// require WPMU_PLUGIN_DIR . '/ua-parser/index.php';
?>