<form action="<?php echo home_url( '/' ); ?>" class="searchform" id="searchform" method="get" role="search">
    <div>
		<label for="s" class="screen-reader-text">Search for:</label>
        <input type="text" class="search-field" placeholder="Search..." name="s" value=""/>
        <input type="submit" value="Search" id="searchsubmit"/>
    </div>
</form>