<?php get_header(); ?>
			
			<div id="content">
			
				<div id="inner-content" class="wrap  clearfix">
								    
				
<div id="inner-page-content">
<div class="border">
<div class="row-fluid">
<div id="main" class="span8  clearfix" role="main">
					    
			<article id="post-not-found" class="hentry clearfix">
									
										<h1 class="heading1"><?php _e("404", "code125"); ?></h1>
										<h2 class="heading3"><?php _e("Not found: The page you're looking for not here anymore, sorry.", "code125"); ?></h2>
										<p><?php _e("Sorry, but the page you were trying to view does not exist.", "code125"); ?></p>
										<p><?php _e("It looks like this was the result of either:", "code125"); ?></p>
										
									
								
									</article> <!-- end article -->
    				</div> <!-- end #main -->
    							   	
    							   	<div id="sidebar" class="sidebar span4 clearfix" role="complementary">
    							   		
    							   		<?php
    							   		
    							   		    get_sidebar('default'); // sidebar Page 
    							   		
    							   		?>
    							   		
    							   	</div>
    							   
                
                </div> <!-- end #inner-content -->
                
			</div> <!-- end #content -->
			</div>
			</div>
			</div>

<?php get_footer(); ?>
