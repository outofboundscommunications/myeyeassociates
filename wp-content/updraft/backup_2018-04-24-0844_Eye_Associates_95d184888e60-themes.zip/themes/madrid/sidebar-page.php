									<?php if ( is_active_sidebar( 'page' ) ) : ?>
				
										<?php dynamic_sidebar( 'page' ); ?>
				
									<?php else : ?>
				
										
				
									<?php endif; ?>
				