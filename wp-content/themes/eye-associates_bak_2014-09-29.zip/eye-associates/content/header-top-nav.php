<nav id="site-navigation" class="main-navigation hidden-xs hidden-sm" role="navigation">
		<?php
		$primary_nav_args = array(
			'theme_location'  => 'primary',
			'menu_class'      => 'nav-menu',
			'menu_id'         => 'menu-primary-menu',
			'container_id'    => 'menu-primary-menu-container',
			'container_class' => 'collapse navbar-collapse',
		);
		wp_nav_menu( $primary_nav_args );
		?>
</nav><!-- #site-navigation -->
<div id="slicknav_menu" class="visible-xs visible-sm"></div>