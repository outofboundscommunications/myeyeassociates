# jquery.matchHeight.js Changelog

[brm.io/jquery-match-height](http://brm.io/jquery-match-height/)

----------

## 0.5.1

- improved demo
- fixed IE8 NaN bug when parsing 'auto' properties
- fixed IE8 window resize event loop bug
- fixed compatibility with older jQuery versions
- added matchHeight('remove')
- added bower package file
- added jquery package file
- added update throttling
- removed forced `display:block` after application

## 0.5.0 - 2014-03-02

- initial release